let tasks = [];
let currentFilter = "all"; // Default filter

function addTask() {
  const taskInput = document.getElementById("taskInput");
  const dueDateInput = document.getElementById("dueDateInput");
  const validationMessage = document.getElementById("validationMessage");
  const task = taskInput.value.trim();
  const dueDate = dueDateInput.value;

  const taskRegex = /^[a-zA-Z0-9 ]+$/;

  if (task === "" || dueDate === "") {
    validationMessage.textContent =
      "Task description and due date are required.";
    return;
  }

  if (!taskRegex.test(task)) {
    validationMessage.textContent =
      "Invalid task description. Use letters, numbers, and spaces only.";
    return;
  }

  tasks.push({ description: task, dueDate: dueDate, completed: false });
  tasks.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));
  taskInput.value = "";
  dueDateInput.value = "";
  validationMessage.textContent = "";
  renderTasks(currentFilter);
  updateBackground();
}

function renderTasks(filter = "all") {
  const taskList = document.getElementById("taskList");
  taskList.innerHTML = "";

  const filteredTasks = tasks.filter((task) => {
    if (filter === "active") return !task.completed;
    if (filter === "completed") return task.completed;
    return true;
  });

  filteredTasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.className = task.completed ? "completed" : "";
    li.onclick = () => toggleTaskCompletion(index);
    li.innerHTML = `${task.description} (Due: ${task.dueDate}) <button onclick="markAsCompleted(event, ${index})">Remove</button>`;
    taskList.appendChild(li);
  });

  updateBackground();
}

function markAsCompleted(event, index) {
  event.stopPropagation();
  tasks[index].completed = true;
  renderTasks(currentFilter);
}

function toggleTaskCompletion(index) {
  tasks[index].completed = !tasks[index].completed;
  renderTasks(currentFilter);
}

function clearCompletedTasks() {
  tasks = tasks.filter((task) => !task.completed);
  renderTasks(currentFilter);
}

function filterTasks(filter) {
  currentFilter = filter;
  renderTasks(filter);
}

function updateBackground() {
  const allCompleted =
    tasks.length > 0 && tasks.every((task) => task.completed);
  document.body.style.backgroundImage = allCompleted
    ? "url('bg1.jpg')"
    : "url('bg2.jpg')";
}
